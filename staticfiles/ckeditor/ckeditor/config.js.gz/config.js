/**
 * @license Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function (config) {
	config.skin = 'kama';
	config.language = 'en';
	config.extraPlugins = 'wordcount,notification,find,dialog,balloontoolbar,sharedSpaces';
	config.sharedSpaces = {
		top: 'top',
		bottom: 'bottom'
	};
};
